=== The Retailer Deprecated Features ===
Contributors: getbowtied, vanesareinerth, adrianlbs
Requires at least: 5.0
Tested up to: 5.5
Stable tag: 1.2.2
Requires PHP: 5.5.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The Retailer Deprecated Features is a new plugin coming with the theme offering a fallback for old features that are no longer used.

Deprecated:
- WPBakery's Page Builder elements

== Changelog ==

= 1.2.1 =
- WordPress 5.5 compatibility updates

= 1.2.1 =
- WordPress 5.3.1 compatibility updates

= 1.2 =
- WordPress 5.3 compatibility updates

= 1.1 =
- Moved deprecated theme templates

= 1.0 =
- Initial Version
