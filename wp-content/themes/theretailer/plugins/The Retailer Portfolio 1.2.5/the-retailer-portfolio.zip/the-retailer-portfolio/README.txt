=== The Retailer Portfolio Addon ===
Contributors: getbowtied, vanesareinerth, adrianlbs
Requires at least: 5.0
Tested up to: 5.5
Stable tag: 1.2.5
Requires PHP: 5.5.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Extends the functionality of your WordPress site by adding a 'Portfolio' custom post type allowing you to organize and showcase your work or products. Companion plugin for the The Retailer theme.

== Changelog ==

= 1.2.5 =
- WordPress 5.5 compatibility updates

= 1.2.4 =
- Small maintenance updates

= 1.2.3 =
- WordPress 5.3.1 compatibility updates

= 1.2.2 =
- WordPress 5.3 compatibility updates

= 1.2.1 =
- Upcoming WordPress 5.3 compatibility updates

= 1.2 =
- The Retailer 3 compatibility updates

= 1.1 =
- Small maintenance updates

= 1.0 =
- Initial Version
